package com.example.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.eap.EapSessionConfig;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.net.ConnectException;
import java.security.Key;


public class MainActivity extends AppCompatActivity {

    private TextView txtProgress;
    private SeekBar seekProgress;

    private SharedPreferences sharedPreferences;
    private static final String KEY = "stored_value";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtProgress = findViewById(R.id.txtProgress);
        seekProgress = findViewById(R.id.seekProgress);

        sharedPreferences = getSharedPreferences("random", Context.MODE_PRIVATE);
        int val = sharedPreferences.getInt(KEY, 0);
        txtProgress.setText(Integer.toString(val));
        seekProgress.setProgress(val);


        seekProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtProgress.setText(Integer.toString(i));
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt(KEY, i);
                editor.apply();


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


}